<?php
        require_once('src/PHPMailer.php');
        require_once('src/SMTP.php');

        $mail = new \PHPMailer(true);

        try {

            
            //Server settings
            $mail->isSMTP();
            //$mail->SMTPDebug = 4;                                // Enable verbose debug output
            //$mail->CharSet = "utf-8";                                   // Set mailer to use SMTP
            $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
            $mail->SMTPAuth = true;                               // Enable SMTP authentication
            $mail->Username = 'leafcodesteam@gmail.com';                 // SMTP username
            $mail->Password = 'teamcodes123';                           // SMTP password
            $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
            $mail->Port = 465;//587; 
            $mail->SMTPOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                )
            );

            //Recipients
            $mail->setFrom('justinjoseph2687@gmail.com', 'Aaadsup Admin');
            $mail->addAddress('justinjoseph287@gmail.com', 'Justin Joseph');     // Add a recipient
            

            //Content
            $mail->isHTML(true);                                  // Set email format to HTML
            $mail->Subject = "trest";
            $mail->Body    = "This is the body in plain text for non-HTML mail clients";
            //$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
            
            echo $mail->send();
            //echo 'Message has been sent';
        } catch (Exception $e) {die($e->getMessage());
            //echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
        }       
